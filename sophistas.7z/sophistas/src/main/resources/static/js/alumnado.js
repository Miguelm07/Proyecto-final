$(document).ready(function(){
	$(".dropdown-trigger").dropdown({hover: true});
	$('.modal').modal();
	$('.modal-trigger').modal();
	$('select').formSelect();
	$('.datepicker').datepicker({
		format:"yyyy-mm-dd"
	});
	obtenerAlumnos();
	//$('.modal-trigger2').modal();
	
	$('#crear').click(function(){
		insertarAlumno();
		Swal.fire({
			  title: 'Informacion',
			  text: 'El alumno ha sido añadido',
			  type: 'success',
			  confirmButtonText: 'continuar'
			})
	})
	
	$('#crear2').click(function(){
		Swal.fire({
			  title: 'Informacion',
			  text: 'Los datos personales del alumno se han modificado',
			  type: 'success',
			  confirmButtonText: 'continuar'
			})
	})
	
	$('#eliminar').click(function(e){
		eliminarAlumno();
		//var form = this;
		//e.preventDefault();
		/*swal({
			  title: "¿Esta seguro de que desea dar de baja el alumno?",
			  icon: "warning",
			  buttons: true,
			  dangerMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
			    swal("El alumno ha sido dadod e baja", {
			      icon: "success",
			    });
			  } else {
			    //swal("Your imaginary file is safe!");
			  }
			});*/
	})

});



function insertarAlumno() {
	// PREPARE FORM DATA
	var formData = {
		apellido1 : $("#apellido1").val(),
		apellido2 : $("#apellido2").val(),
		correo : $("#correo").val(),
		cursos_id : "b",
		fecha_alta : $("#fecha_alta").val(),
		fecha_baja : $("#fecha_alta").val(),
		nif : $("#nif").val(),
		nombre : $("#nombre").val(),
		observaciones : $("#observaciones").val(),
		repetidor : true,
		responsables_alumnos : "b",
		telefono : $("#telefono").val()
	}
	

	// DO POST
	$.ajax({
		type : "POST",
		contentType : "application/json",
		url : "/api/v1/estudiantes",
		data : JSON.stringify(formData),
		dataType : 'json',
		success : function(result) {
			if (result.status == "success") {
				$("#postResultDiv").html(
						"" + result.data.bookName
								+ "Post Successfully! <br>"
								+ "---> Congrats !!" + "</p>");
			} else {
				$("#postResultDiv").html("<strong>Error</strong>");
			}
			console.log(result);
		},
		error : function(e) {
			alert("Error!")
			console.log("ERROR: ", e);
		}
	});

}

function eliminarAlumno() {
	alert("si funciona 2");

	// PREPARE FORM DATA
	var formData = {
		id : 2
	}
	

	// DO POST
	$.ajax({
		type : "DELETE",
		contentType : "application/json",
		url : "/api/v1/estudiantes/3",
		success : function(result) {
			if (result.status == "success") {
				$("#postResultDiv").html(
						"" + result.data.bookName
								+ "Post Successfully! <br>"
								+ "---> Congrats !!" + "</p>");
			} else {
				$("#postResultDiv").html("<strong>Error</strong>");
			}
			console.log(result);
		},
		error : function(e) {
			alert("Error!")
			console.log("ERROR: ", e);
		}
	});

}

function obtenerAlumnos() {

	// DO POST
	$.ajax({
		type : "GET",
		contentType : "application/json",
		url : "/api/v1/estudiantes",
		dataType : 'json',
		success : function(result) {
			result.forEach(function(element) {
				$(".highlight").append( "<tr>"+"<td id='nombre_alum'>" + element["nombre"] + "</td>"+ 
						"<td id='curso_alum'>" + element["cursos_id"] + "</td>"+
						"<td id='responsable_alum'>" + element["responsables_alumnos"] + "</td>"+
						"<td id='fecha_alta_alum'>" + element["fecha_alta"] + "</td>"+
						"<td id='fecha_baja_alum'>" + element["fecha_baja"] + "</td>"+"</tr>" );
				console.log(element["sede"]);
				});
			
			$('#aplicar').click(function(e){
				ajaxPost("1",$(this).parent().find("#sede").html());
			})
			//alert(result[0]["nombre"])
			console.log(result);
		},
		error : function(e) {
			alert("Error!")
			console.log("ERROR: ", e);
		}
	});

}

function obtenerAlumno() {
	alert("si funciona 2");

	// PREPARE FORM DATA
	var formData = {
		id : 2
	}
	

	// DO POST
	$.ajax({
		type : "GET",
		contentType : "application/json",
		url : "/api/v1/estudiantes/3",
		success : function(result) {
			if (result.status == "success") {
				$("#postResultDiv").html(
						"" + result.data.bookName
								+ "Post Successfully! <br>"
								+ "---> Congrats !!" + "</p>");
			} else {
				$("#postResultDiv").html("<strong>Error</strong>");
			}
			console.log(result);
		},
		error : function(e) {
			alert("Error!")
			console.log("ERROR: ", e);
		}
	});

}