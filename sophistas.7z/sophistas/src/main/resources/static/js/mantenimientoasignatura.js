$(document).ready(function(){
	$(".dropdown-trigger").dropdown({hover: true});
	$('.modal').modal();
	$('.modal-trigger').modal();
	$('select').formSelect();
	$('.datepicker').datepicker();
	//$('.modal-trigger2').modal();
	
	$('#crear').click(function(){
		Swal.fire({
			  title: 'Informacion',
			  text: 'El curso ha sido creado',
			  type: 'success',
			  confirmButtonText: 'continuar'
			})
	})
	
	$('#crear2').click(function(){
		Swal.fire({
			  title: 'Informacion',
			  text: 'el curso ha sido modificado',
			  type: 'success',
			  confirmButtonText: 'continuar'
			})
	})
	
	$('#eliminar').click(function(e){
		var form = this;
		e.preventDefault();
		swal({
			  title: "¿Esta seguro de que desea eliminar el curso?",
			  icon: "warning",
			  buttons: true,
			  dangerMode: true,
			})
			.then((willDelete) => {
			  if (willDelete) {
			    swal("El curso ha sido eliminado", {
			      icon: "success",
			    });
			  } else {
			    //swal("Your imaginary file is safe!");
			  }
			});
	})

});